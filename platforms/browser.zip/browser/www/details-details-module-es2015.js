(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["details-details-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-header no-border>\n  <ion-toolbar>\n    <ion-buttons slot=\"start\">\n      <ion-back-button></ion-back-button>\n    </ion-buttons>\n    <img alt=\"logo\" slot=\"end\" height=\"40px\" src=\"assets/img/Logo_WhiteStacked_1024x1024.png\">\n      <ion-buttons slot=\"end\">\n      <ion-menu-button></ion-menu-button>\n      </ion-buttons>\n    <ion-title>\n      {{title | translate}}\n    </ion-title>\n  </ion-toolbar>\n</ion-header>\n\n<ion-content class=\"ion-padding\">       \n\n  <ion-card style=\"align-content: flex-start\">\n    <ion-card-content>\n    <ion-card-header>\n      <ion-card-title class=\"ion-text-wrap\">{{resource.ProgramName}}</ion-card-title>\n    </ion-card-header>\n    <ion-row>\n      <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Description}}</ion-label>\n      <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Description_es}}</ion-label>\n      <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Description_fr}}</ion-label>\n      <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Description_vi}}</ion-label>\n      <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Description_zh}}</ion-label>\n      <!-- <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Description_vi}}</ion-label> -->\n  </ion-row>\n  </ion-card-content>\n  </ion-card>\n\n  <ion-card style=\"align-content: flex-start\">\n      <ion-card-content>\n        <ion-card-header><h2><b>{{address | translate}}</b></h2></ion-card-header>\n        <ion-row>\n                <!-- <ion-col col-10> -->\n                    <ion-label class=\"text-wrap\"><a href=\"https://maps.google.com/maps?q={{resource.Address}} {{resource.LocationCity}}, {{resource.LocationState}} {{resource.Zip}}\" target=\"_blank\">{{resource.Address}} {{resource.LocationCity}}, {{resource.LocationState}} {{resource.Zip}}</a></ion-label>\n                <!-- </ion-col> -->\n                <!-- <ion-col col-2> -->\n                     <!-- <ion-button shape=\"round\" (click)=\"navigate()\"><ion-icon name=\"locate\"></ion-icon></ion-button> -->\n                <!-- </ion-col> -->\n      </ion-row>\n    </ion-card-content>\n    </ion-card>\n\n    <ion-card style=\"align-content: flex-start\">\n      <ion-card-content>\n          <ion-card-header><h2><b>{{telephone | translate}}</b></h2></ion-card-header>\n        <ion-row>\n                <!-- <ion-col col-10> -->\n                    <ion-label class=\"ion-text-wrap\"><a href=\"tel:{{resource.TelephoneNumber1}}\">{{resource.TelephoneNumber1}}</a></ion-label>\n                 <!-- </ion-col> -->\n                <!-- <ion-col col-2> -->\n                    <!-- <ion-button shape=\"round\" (click)=\"phone()\"><ion-icon name=\"call\"></ion-icon></ion-button>  -->\n                    <!-- <a href=\"tel:+\" + {{resource.TelephoneNumber1}}><ion-icon name=\"call\"></ion-icon></a> -->\n                <!-- </ion-col>  -->\n      </ion-row>\n    </ion-card-content>\n    </ion-card>\n\n    <ion-card style=\"align-content: flex-start\">\n      <ion-card-content>\n          <ion-card-header><h2><b>{{hours | translate}}</b></h2></ion-card-header>\n          <ion-row>\n            <ion-label class=\"ion-text-wrap\">{{resource.Hours}}</ion-label>\n        <!-- <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Hours}}</ion-label>\n        <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Hours_es}}</ion-label>\n        <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Hours_fr}}</ion-label>\n        <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Hours_vi}}</ion-label>\n        <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Hours_zh}}</ion-label> -->\n      </ion-row>\n      </ion-card-content>\n    </ion-card>\n\n    <ion-card style=\"background-color: blue;\" *ngIf=\"resource.Website !== '';\" style=\"align-content: flex-start\">\n      <ion-card-content>\n          <ion-card-header><h2><b>{{website | translate}}</b></h2></ion-card-header>\n          <ion-row>\n          <ion-label class=\"ion-text-wrap\"><a href=\"{{resource.Website}}\" target=\"_blank\">{{resource.Website}}</a></ion-label>\n        </ion-row>\n        <!-- <ion-button (click)=\"openWebpage()\">{{resource.Website}}</ion-button> -->\n      </ion-card-content>\n    </ion-card>\n\n      <ion-card style=\"align-content: flex-start\">\n        <ion-card-content>\n            <ion-card-header><h2><b>{{categories | translate}}</b></h2></ion-card-header>\n            <ion-row>\n          <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Category}}</ion-label>\n          <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Category_es}}</ion-label>\n          <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Category_fr}}</ion-label>\n          <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Category_vi}}</ion-label>\n          <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Category_zh}}</ion-label>\n        </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card style=\"align-content: flex-start\">\n        <ion-card-content>\n            <ion-card-header><h2><b>{{eligibility | translate}}</b></h2></ion-card-header>\n            <ion-row>\n          <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Eligibility}}</ion-label>\n          <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Eligibility_es}}</ion-label>\n          <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Eligibility_fr}}</ion-label>\n          <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Eligibility_vi}}</ion-label>\n          <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Eligibility_zh}}</ion-label>\n        </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card style=\"align-content: flex-start\">\n        <ion-card-content>\n            <ion-card-header><h2><b>{{ageserved | translate}}</b></h2></ion-card-header>\n            <ion-row>\n          <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.AgeServed}}</ion-label>\n          <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.AgeServed_es}}</ion-label>\n          <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.AgeServed_fr}}</ion-label>\n          <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.AgeServed_vi}}</ion-label>\n          <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.AgeServed_zh}}</ion-label>\n        </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n      <ion-card style=\"align-content: flex-start\">\n        <ion-card-content>\n            <ion-card-header><h2><b>{{fee | translate}}</b></h2></ion-card-header>\n            <ion-row>\n              <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Fees}}</ion-label>\n              <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Fees_es}}</ion-label>\n              <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Fees_fr}}</ion-label>\n              <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Fees_vi}}</ion-label>\n              <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Fees_zh}}</ion-label>\n          <!-- <ion-label *ngIf=\"language === 'en'\" class=\"ion-text-wrap\">{{resource.Fees}}</ion-label>\n          <ion-label *ngIf=\"language === 'es'\" class=\"ion-text-wrap\">{{resource.Fees_es}}</ion-label>\n          <ion-label *ngIf=\"language === 'fr'\" class=\"ion-text-wrap\">{{resource.Fees_fr}}</ion-label>\n          <ion-label *ngIf=\"language === 'vi'\" class=\"ion-text-wrap\">{{resource.Fees_vi}}</ion-label>\n          <ion-label *ngIf=\"language === 'zh'\" class=\"ion-text-wrap\">{{resource.Fees_zh}}</ion-label> -->\n        </ion-row>\n        </ion-card-content>\n      </ion-card>\n\n\n      <!-- <ion-fab vertical=\"top\" horizontal=\"end\" slot=\"fixed\">\n        <ion-fab-button class=\"unfavorite\" (click)=\"unfavoriteResource()\" *ngIf=\"isFavorite\">\n          <ion-icon  large name=\"heart\"></ion-icon>\n        </ion-fab-button>\n        <ion-fab-button class=\"favorite\" (click)=\"favoriteResource()\" *ngIf=\"!isFavorite\">\n          <ion-icon large name=\"heart\"></ion-icon>\n        </ion-fab-button>\n      </ion-fab> -->\n\n      <ion-fab vertical=\"bottom\" horizontal=\"end\" slot=\"fixed\">\n        <ion-fab-button (click)=\"presentActionSheet()\" [translate]>\n          <ion-icon name=\"share\"></ion-icon>\n        </ion-fab-button>\n      </ion-fab> \n</ion-content>");

/***/ }),

/***/ "./src/app/details/details.module.ts":
/*!*******************************************!*\
  !*** ./src/app/details/details.module.ts ***!
  \*******************************************/
/*! exports provided: DetailsPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPageModule", function() { return DetailsPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _details_page__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./details.page */ "./src/app/details/details.page.ts");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");





// import { DetailsPageRoutingModule } from './details-routing.module';



// const routes: Routes = [
//   {
//     path: '',
//     component: DetailsPage
//   }
// ];
let DetailsPageModule = class DetailsPageModule {
};
DetailsPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _ngx_translate_core__WEBPACK_IMPORTED_MODULE_7__["TranslateModule"],
            _angular_router__WEBPACK_IMPORTED_MODULE_6__["RouterModule"].forChild([
                {
                    path: '',
                    component: _details_page__WEBPACK_IMPORTED_MODULE_5__["DetailsPage"]
                }
            ])
        ],
        declarations: [_details_page__WEBPACK_IMPORTED_MODULE_5__["DetailsPage"]]
    })
], DetailsPageModule);



/***/ }),

/***/ "./src/app/details/details.page.scss":
/*!*******************************************!*\
  !*** ./src/app/details/details.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("/* Removes header drop shadow */\nion-header {\n  z-index: 0;\n}\n/* Styles top toolbar */\nion-toolbar {\n  color: white;\n  --background: #3064ab;\n  box-shadow: none;\n}\n/* Styles background color of every item on page content*/\nion-content {\n  --ion-background-color: linear-gradient(180deg, #3064ab 0%, #0c499c 50%, #03216e 100%) !important;\n}\n/* Styles each resources font colors*/\np {\n  text-align: left;\n  color: #fff;\n}\nb {\n  color: #fff;\n  font-size: 12pt;\n}\nion-card-title {\n  color: #fff;\n}\nion-label {\n  color: #fff;\n}\n/* Styles each resources background color*/\nion-list {\n  --color: var(--ion-color-step-850,#fff);\n  --background: transparent !important;\n}\n/* Styles resource information padding-left*/\nion-row {\n  padding-left: 25px !important;\n}\n/* Styles both button background color*/\nion-fab-button {\n  --background: radial-gradient(#00cd67 20%, #01ff80 100%) !important;\n}\n/* Styles favorite button heart icon*/\n.favorite {\n  --color: #fff !important;\n}\n.unfavorite {\n  --color: #c13832 !important;\n}\n/* Makes Ion Card Transparent*/\nion-card {\n  --background: transparent !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIi9Vc2Vycy9uaWNrcmljaGFyZC9Eb2N1bWVudHMvYXBwLWJhc2Utc3Qvc3JjL2FwcC9kZXRhaWxzL2RldGFpbHMucGFnZS5zY3NzIiwic3JjL2FwcC9kZXRhaWxzL2RldGFpbHMucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLCtCQUFBO0FBQ0E7RUFDRSxVQUFBO0FDQ0Y7QURDQSx1QkFBQTtBQUNBO0VBQ0ksWUFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0JBQUE7QUNFSjtBREFJLHlEQUFBO0FBQ0E7RUFDQSxpR0FBQTtBQ0dKO0FEREkscUNBQUE7QUFDQTtFQUNBLGdCQUFBO0VBQ0EsV0FBQTtBQ0lKO0FERkk7RUFDQSxXQUFBO0VBQ0EsZUFBQTtBQ0tKO0FESEk7RUFDSSxXQUFBO0FDTVI7QURKSTtFQUNJLFdBQUE7QUNPUjtBRExJLDBDQUFBO0FBQ0E7RUFDQSx1Q0FBQTtFQUNBLG9DQUFBO0FDUUo7QUROSSw0Q0FBQTtBQUNBO0VBQ0ksNkJBQUE7QUNTUjtBRFBJLHVDQUFBO0FBQ0o7RUFDSSxtRUFBQTtBQ1VKO0FEUkUscUNBQUE7QUFDQTtFQUNFLHdCQUFBO0FDV0o7QURURTtFQUNFLDJCQUFBO0FDWUo7QURWRSw4QkFBQTtBQUNEO0VBQ0Usb0NBQUE7QUNhSCIsImZpbGUiOiJzcmMvYXBwL2RldGFpbHMvZGV0YWlscy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyIvKiBSZW1vdmVzIGhlYWRlciBkcm9wIHNoYWRvdyAqL1xuaW9uLWhlYWRlciB7XG4gIHotaW5kZXg6IDA7XG59XG4vKiBTdHlsZXMgdG9wIHRvb2xiYXIgKi9cbmlvbi10b29sYmFyIHtcbiAgICBjb2xvcjogd2hpdGU7XG4gICAgLS1iYWNrZ3JvdW5kOiAjMzA2NGFiO1xuICAgIGJveC1zaGFkb3c6IG5vbmU7XG4gICAgfVxuICAgIC8qIFN0eWxlcyBiYWNrZ3JvdW5kIGNvbG9yIG9mIGV2ZXJ5IGl0ZW0gb24gcGFnZSBjb250ZW50Ki9cbiAgICBpb24tY29udGVudHtcbiAgICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiBsaW5lYXItZ3JhZGllbnQoMTgwZGVnLCAjMzA2NGFiIDAlLCAjMGM0OTljIDUwJSwgIzAzMjE2ZSAxMDAlKSAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAvKiBTdHlsZXMgZWFjaCByZXNvdXJjZXMgZm9udCBjb2xvcnMqL1xuICAgIHAge1xuICAgIHRleHQtYWxpZ246IGxlZnQ7XG4gICAgY29sb3I6ICNmZmY7XG4gICAgfVxuICAgIGIge1xuICAgIGNvbG9yOiAjZmZmO1xuICAgIGZvbnQtc2l6ZTogMTJwdDtcbiAgICB9XG4gICAgaW9uLWNhcmQtdGl0bGUge1xuICAgICAgICBjb2xvcjogI2ZmZjtcbiAgICB9XG4gICAgaW9uLWxhYmVsIHtcbiAgICAgICAgY29sb3I6ICNmZmY7XG4gICAgfVxuICAgIC8qIFN0eWxlcyBlYWNoIHJlc291cmNlcyBiYWNrZ3JvdW5kIGNvbG9yKi9cbiAgICBpb24tbGlzdCB7XG4gICAgLS1jb2xvcjogdmFyKC0taW9uLWNvbG9yLXN0ZXAtODUwLCNmZmYpO1xuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgICB9XG4gICAgLyogU3R5bGVzIHJlc291cmNlIGluZm9ybWF0aW9uIHBhZGRpbmctbGVmdCovXG4gICAgaW9uLXJvdyB7XG4gICAgICAgIHBhZGRpbmctbGVmdDogMjVweCAhaW1wb3J0YW50O1xuICAgIH1cbiAgICAvKiBTdHlsZXMgYm90aCBidXR0b24gYmFja2dyb3VuZCBjb2xvciovXG5pb24tZmFiLWJ1dHRvbiB7XG4gICAgLS1iYWNrZ3JvdW5kOiByYWRpYWwtZ3JhZGllbnQoIzAwY2Q2NyAyMCUsICMwMWZmODAgMTAwJSkgIWltcG9ydGFudDtcbiAgfVxuICAvKiBTdHlsZXMgZmF2b3JpdGUgYnV0dG9uIGhlYXJ0IGljb24qL1xuICAuZmF2b3JpdGUge1xuICAgIC0tY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbiAgfVxuICAudW5mYXZvcml0ZSB7XG4gICAgLS1jb2xvcjogI2MxMzgzMiAhaW1wb3J0YW50O1xuICB9XG4gIC8qIE1ha2VzIElvbiBDYXJkIFRyYW5zcGFyZW50Ki9cbiBpb24tY2FyZCB7XG4gICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50ICFpbXBvcnRhbnQ7XG4gfSIsIi8qIFJlbW92ZXMgaGVhZGVyIGRyb3Agc2hhZG93ICovXG5pb24taGVhZGVyIHtcbiAgei1pbmRleDogMDtcbn1cblxuLyogU3R5bGVzIHRvcCB0b29sYmFyICovXG5pb24tdG9vbGJhciB7XG4gIGNvbG9yOiB3aGl0ZTtcbiAgLS1iYWNrZ3JvdW5kOiAjMzA2NGFiO1xuICBib3gtc2hhZG93OiBub25lO1xufVxuXG4vKiBTdHlsZXMgYmFja2dyb3VuZCBjb2xvciBvZiBldmVyeSBpdGVtIG9uIHBhZ2UgY29udGVudCovXG5pb24tY29udGVudCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IGxpbmVhci1ncmFkaWVudCgxODBkZWcsICMzMDY0YWIgMCUsICMwYzQ5OWMgNTAlLCAjMDMyMTZlIDEwMCUpICFpbXBvcnRhbnQ7XG59XG5cbi8qIFN0eWxlcyBlYWNoIHJlc291cmNlcyBmb250IGNvbG9ycyovXG5wIHtcbiAgdGV4dC1hbGlnbjogbGVmdDtcbiAgY29sb3I6ICNmZmY7XG59XG5cbmIge1xuICBjb2xvcjogI2ZmZjtcbiAgZm9udC1zaXplOiAxMnB0O1xufVxuXG5pb24tY2FyZC10aXRsZSB7XG4gIGNvbG9yOiAjZmZmO1xufVxuXG5pb24tbGFiZWwge1xuICBjb2xvcjogI2ZmZjtcbn1cblxuLyogU3R5bGVzIGVhY2ggcmVzb3VyY2VzIGJhY2tncm91bmQgY29sb3IqL1xuaW9uLWxpc3Qge1xuICAtLWNvbG9yOiB2YXIoLS1pb24tY29sb3Itc3RlcC04NTAsI2ZmZik7XG4gIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbn1cblxuLyogU3R5bGVzIHJlc291cmNlIGluZm9ybWF0aW9uIHBhZGRpbmctbGVmdCovXG5pb24tcm93IHtcbiAgcGFkZGluZy1sZWZ0OiAyNXB4ICFpbXBvcnRhbnQ7XG59XG5cbi8qIFN0eWxlcyBib3RoIGJ1dHRvbiBiYWNrZ3JvdW5kIGNvbG9yKi9cbmlvbi1mYWItYnV0dG9uIHtcbiAgLS1iYWNrZ3JvdW5kOiByYWRpYWwtZ3JhZGllbnQoIzAwY2Q2NyAyMCUsICMwMWZmODAgMTAwJSkgIWltcG9ydGFudDtcbn1cblxuLyogU3R5bGVzIGZhdm9yaXRlIGJ1dHRvbiBoZWFydCBpY29uKi9cbi5mYXZvcml0ZSB7XG4gIC0tY29sb3I6ICNmZmYgIWltcG9ydGFudDtcbn1cblxuLnVuZmF2b3JpdGUge1xuICAtLWNvbG9yOiAjYzEzODMyICFpbXBvcnRhbnQ7XG59XG5cbi8qIE1ha2VzIElvbiBDYXJkIFRyYW5zcGFyZW50Ki9cbmlvbi1jYXJkIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xufSJdfQ== */");

/***/ }),

/***/ "./src/app/details/details.page.ts":
/*!*****************************************!*\
  !*** ./src/app/details/details.page.ts ***!
  \*****************************************/
/*! exports provided: DetailsPage, snapshotToObject */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "DetailsPage", function() { return DetailsPage; });
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "snapshotToObject", function() { return snapshotToObject; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @ionic-native/call-number/ngx */ "./node_modules/@ionic-native/call-number/ngx/index.js");
/* harmony import */ var _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @ionic-native/launch-navigator/ngx */ "./node_modules/@ionic-native/launch-navigator/ngx/index.js");
/* harmony import */ var rxjs_add_operator_map__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! rxjs/add/operator/map */ "./node_modules/rxjs-compat/_esm2015/add/operator/map.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! rxjs/add/operator/toPromise */ "./node_modules/rxjs-compat/_esm2015/add/operator/toPromise.js");
/* harmony import */ var rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_add_operator_toPromise__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @ionic-native/in-app-browser/ngx */ "./node_modules/@ionic-native/in-app-browser/ngx/index.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _services_favorites_list_service__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(/*! ../services/favorites-list.service */ "./src/app/services/favorites-list.service.ts");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(/*! firebase */ "./node_modules/firebase/dist/index.cjs.js");
/* harmony import */ var firebase__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(firebase__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _share_modal_share_modal_page__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(/*! ../share-modal/share-modal.page */ "./src/app/share-modal/share-modal.page.ts");
/* harmony import */ var _flag_flag_page__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(/*! ../flag/flag.page */ "./src/app/flag/flag.page.ts");
/* harmony import */ var _ionic_native_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(/*! @ionic-native/firebase-analytics/ngx */ "./node_modules/@ionic-native/firebase-analytics/ngx/index.js");
/* harmony import */ var _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(/*! @ngx-translate/core */ "./node_modules/@ngx-translate/core/fesm2015/ngx-translate-core.js");












// import { PhoneselectModalPage } from '../phoneselect-modal/phoneselect-modal.page';




let DetailsPage = class DetailsPage {
    constructor(callNumber, launchNavigator, inAppBrowser, modalController, toastController, platform, favoriteProvider, route, router, actionSheetController, firebaseAnalytics, _translate) {
        // this.resource = history.state.data
        this.callNumber = callNumber;
        this.launchNavigator = launchNavigator;
        this.inAppBrowser = inAppBrowser;
        this.modalController = modalController;
        this.toastController = toastController;
        this.platform = platform;
        this.favoriteProvider = favoriteProvider;
        this.route = route;
        this.router = router;
        this.actionSheetController = actionSheetController;
        this.firebaseAnalytics = firebaseAnalytics;
        this._translate = _translate;
        this.resource = {
            key: '',
            Address: '',
            AgeServed: '',
            ApplicationProcess: '',
            Category: '',
            CoverageArea: '',
            Description: '',
            Description_es: '',
            Description_fr: '',
            Description_vi: '',
            Description_zh: '',
            Eligibility: '',
            EmailAddress: '',
            Fax: '',
            Fees: '',
            Hours: '',
            LocationCity: '',
            LocationState: '',
            ProgramName: '',
            TelephoneDescription1: '',
            TelephoneNumber1: '',
            TelephoneNumber2: '',
            TelephoneNumber2Description: '',
            Website: '',
            Zip: '',
            id: '',
            isFavorite: false
        };
        this.resources = [];
        this.newResource = {};
        this.newFavorites = {};
        this.router.routeReuseStrategy.shouldReuseRoute = function () {
            return false;
        };
        console.log(this.router.url);
        console.log(this.route.snapshot.paramMap.get('key'));
        firebase__WEBPACK_IMPORTED_MODULE_9__["database"]().ref('resource/' + this.route.snapshot.paramMap.get('key')).on('value', resp => {
            this.resource = snapshotToObject(resp);
            console.log(this.resource);
            return false;
        });
        console.log(this.resource);
        this.resourceString = JSON.stringify(this.resource);
        this.favoriteProvider.isFavorite(this.resourceString).then(isFav => {
            this.isFavorite = isFav;
        });
        // this.firebaseAnalytics.logEvent('resource_viewed', {page: this.resource.ProgramName })
    }
    ngOnInit() {
        this.language = this._translate.getDefaultLang();
        console.log(this.language);
        this.firebaseAnalytics.logEvent('resource_viewed', { resource_viewed: this.resource.ProgramName });
        this.title = 'page.details';
        this.address = 'details.address';
        this.telephone = 'details.phone';
        this.hours = 'details.hours';
        this.categories = 'details.categories';
        this.eligibility = 'details.eligibility';
        this.ageserved = 'details.ageserved';
        this.website = 'details.website';
        this.fee = 'details.fee';
        this._translate.get('details.flag').subscribe((res) => {
            console.log(res);
            this.flag = res;
        });
        this._translate.get('details.share').subscribe((res) => {
            console.log(res);
            this.share = res;
        });
        this._translate.get('details.call').subscribe((res) => {
            console.log(res);
            this.call = res;
        });
        this._translate.get('details.navigate').subscribe((res) => {
            console.log(res);
            this.navigateTo = res;
        });
        this._translate.get('details.website').subscribe((res) => {
            console.log(res);
            this.goToWebsite = res;
        });
        this._translate.get('sharemenu.cancel').subscribe((res) => {
            console.log(res);
            this.cancel = res;
        });
        this._translate.get('sharemenu.share').subscribe((res) => {
            console.log(res);
            this.acShare = res;
        });
    }
    showToast(msg) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: msg,
                duration: 2000
            });
            toast.present();
        });
    }
    openModal(data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _share_modal_share_modal_page__WEBPACK_IMPORTED_MODULE_11__["ShareModalPage"],
                componentProps: {
                    "message": data
                }
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    this.dataReturned = dataReturned.data;
                    // alert('Modal Sent Data :'+ this.dataReturned);
                }
            });
            return yield modal.present();
        });
    }
    openFlagModal(data) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const modal = yield this.modalController.create({
                component: _flag_flag_page__WEBPACK_IMPORTED_MODULE_12__["FlagPage"],
                componentProps: {
                    "message": data
                }
            });
            modal.onDidDismiss().then((dataReturned) => {
                if (dataReturned !== null) {
                    this.dataReturned = dataReturned.data;
                    // alert('Modal Sent Data :'+ this.dataReturned);
                }
            });
            return yield modal.present();
        });
    }
    presentActionSheet() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const actionSheet = yield this.actionSheetController.create({
                header: this.acShare,
                buttons: [{
                        text: this.flag,
                        role: 'destructive',
                        icon: 'flag',
                        handler: () => {
                            this.flagResource();
                            // this.router.navigate(['/home'])
                            // this.clearSelected();
                            console.log('Opening Flag Modal');
                        }
                    }, {
                        text: this.share,
                        icon: 'share',
                        handler: () => {
                            this.regularShare();
                            console.log('Opening Share Modal');
                        }
                    }, {
                        text: this.cancel,
                        icon: 'close',
                        role: 'cancel',
                        handler: () => {
                            console.log('Cancel clicked');
                        }
                    }]
            });
            yield actionSheet.present();
        });
    }
    favoriteResource() {
        this.favoriteProvider.favoriteResource(this.resourceString).then(() => {
            this.isFavorite = true;
            this.showToast('Resource added to Favorites.');
        });
        this.firebaseAnalytics.logEvent('favorite_added', { favorite_added: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
    unfavoriteResource() {
        this.favoriteProvider.unfavoriteResource(this.resourceString).then(() => {
            this.isFavorite = false;
            this.showToast('Resource removed from Favorites.');
        });
        this.firebaseAnalytics.logEvent('favorite_removed', { favorite_removed: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
    openWebpage() {
        let fixedUrl = this.resource.Website;
        const options = {
            zoom: 'no'
        };
        const browser = this.inAppBrowser.create(fixedUrl, '_system', options);
        this.firebaseAnalytics.logEvent('website_opened', { website_visit: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
    phone() {
        this.callNumber.callNumber(this.resource.TelephoneNumber1, true)
            .then(() => console.log('Launched dialer!'))
            .catch(() => console.log('Error launching dialer'));
        this.firebaseAnalytics.logEvent('resource_called', { resource_called: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
    navigate() {
        let options = {
            start: this.start
        };
        var address = this.resource.Address.toString() + " " + this.resource.LocationCity.toString() + ", " + this.resource.LocationState.toString() + " " + this.resource.Zip.toString();
        this.launchNavigator.navigate(address, options)
            .then(success => alert('Launched navigator'), error => alert('Error launching navigator: ' + error));
        this.firebaseAnalytics.logEvent('navigator_opened', { resource_navigated: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
    regularShare() {
        if (this.language == 'en') {
            var msg = this.resource.ProgramName + '\n' + this.resource.Description + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
            msg = msg + "This information is provided by NAMI St. Tammany.  For more behavioral health information www.namist.org" + '\n';
        }
        if (this.language == 'es') {
            var msg = this.resource.ProgramName + '\n' + this.resource.Description_es + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
            msg = msg + "Esta información es proporcionada por NAMI St. Tammany. Para obtener más información sobre salud del comportamiento www.namist.org" + '\n';
        }
        if (this.language == 'fr') {
            var msg = this.resource.ProgramName + '\n' + this.resource.Description_fr + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
            msg = msg + "Ces informations sont fournies par NAMI St. Tammany. Pour plus d'informations sur la santé comportementale www.namist.org" + '\n';
        }
        if (this.language == 'vi') {
            var msg = this.resource.ProgramName + '\n' + this.resource.Description_vi + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
            msg = msg + "Thông tin này được cung cấp bởi NAMI St. Tammany. Để biết thêm thông tin về sức khỏe hành vi, www.namist.org" + '\n';
        }
        if (this.language == 'zh') {
            var msg = this.resource.ProgramName + '\n' + +this.resource.Description_zh + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
            msg = msg + "此信息由 NAMI St. Tammany 提供。如需更多行为健康信息，请访问 www.namist.org" + '\n';
        }
        var data = { message: msg };
        this.openModal(data).then(() => {
            // this.router.navigate(['/home'])
        });
        this.firebaseAnalytics.logEvent('resource_shared', { resource_shared: this.resource.ProgramName });
    }
    flagResource() {
        var msg = this.resource.ProgramName + '\n' + this.resource.TelephoneNumber1 + '\n' + this.resource.EmailAddress + '\n' + this.resource.Website + '\n';
        var data = { message: msg };
        this.openFlagModal(data).then(() => {
            // this.router.navigate(['/home'])
        });
        this.firebaseAnalytics.logEvent('resource_flagged', { resource_flagged: this.resource.ProgramName });
        // .then((res: any) => console.log(res))
        // .catch((error: any) => console.error(error));
    }
};
DetailsPage.ctorParameters = () => [
    { type: _ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_2__["CallNumber"] },
    { type: _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"] },
    { type: _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__["InAppBrowser"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"] },
    { type: _services_favorites_list_service__WEBPACK_IMPORTED_MODULE_8__["FavoritesListService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ActionSheetController"] },
    { type: _ionic_native_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_13__["FirebaseAnalytics"] },
    { type: _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__["TranslateService"] }
];
DetailsPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
        selector: 'app-details',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./details.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/details/details.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./details.page.scss */ "./src/app/details/details.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_native_call_number_ngx__WEBPACK_IMPORTED_MODULE_2__["CallNumber"],
        _ionic_native_launch_navigator_ngx__WEBPACK_IMPORTED_MODULE_3__["LaunchNavigator"],
        _ionic_native_in_app_browser_ngx__WEBPACK_IMPORTED_MODULE_6__["InAppBrowser"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ModalController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ToastController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["Platform"],
        _services_favorites_list_service__WEBPACK_IMPORTED_MODULE_8__["FavoritesListService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_10__["ActivatedRoute"],
        _angular_router__WEBPACK_IMPORTED_MODULE_10__["Router"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_7__["ActionSheetController"],
        _ionic_native_firebase_analytics_ngx__WEBPACK_IMPORTED_MODULE_13__["FirebaseAnalytics"],
        _ngx_translate_core__WEBPACK_IMPORTED_MODULE_14__["TranslateService"]])
], DetailsPage);

const snapshotToObject = snapshot => {
    const item = snapshot.val();
    item.key = snapshot.key;
    // console.log(item);
    return item;
};


/***/ })

}]);
//# sourceMappingURL=details-details-module-es2015.js.map